import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { ArrowLeft, Plus, Edit, Mail, Phone, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { ContactForm } from "@/components/contact-form";
import { ContactDetailModal } from "@/components/contact-detail-modal";
import { GmailEmailComposer } from "@/components/email/gmail-email-composer";
import { WeeklyAvailabilityEditor } from "@/components/weekly-availability-editor";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface PersonnelCategoryParams {
  id: string;
  category: string;
}

interface Contact {
  id: number;
  projectId: number;
  firstName: string;
  lastName: string;
  email?: string;
  phone?: string;
  groupId?: number;
  contactGroup?: { name: string };
  role?: string;
  notes?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactEmail?: string;
  emergencyContactRelationship?: string;
  allergies?: string;
  medicalNotes?: string;
  castTypes?: string[];
  createdAt?: Date | string;
  updatedAt?: Date | string;
}

export default function PersonnelCategory() {
  const [, setLocation] = useLocation();
  const params = useParams<PersonnelCategoryParams>();
  const projectId = params.id;
  const groupParam = params.category;

  // Guard against missing parameters
  if (!projectId || !groupParam) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold text-foreground mb-2">Personnel Group Not Found</h1>
          <p className="text-muted-foreground mb-4">The personnel group you're looking for doesn't exist or the URL is invalid.</p>
          <Button onClick={() => setLocation('/shows')}>
            Go to Shows
          </Button>
        </div>
      </div>
    );
  }
  
  // Parse group param: "group-123" -> groupId 123, "unassigned" -> null
  const isUnassigned = groupParam === 'unassigned';
  const parsedGroupId = groupParam.startsWith('group-') ? parseInt(groupParam.slice(6)) : null;
  const groupId = (parsedGroupId !== null && !isNaN(parsedGroupId)) ? parsedGroupId : null;
  
  // If the URL has a malformed group ID (e.g., group-abc), treat as invalid
  const isInvalidGroupParam = groupParam.startsWith('group-') && (parsedGroupId === null || isNaN(parsedGroupId));
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);

  const [showFormModal, setShowFormModal] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const queryClient = useQueryClient();

  // Email composer state
  const [showEmailComposer, setShowEmailComposer] = useState(false);
  
  // Availability dialog state
  const [availabilityContact, setAvailabilityContact] = useState<Contact | null>(null);
  const [composerRecipient, setComposerRecipient] = useState('');
  const [composerFromAccount, setComposerFromAccount] = useState<any>(null);

  const { data: project } = useQuery({
    queryKey: [`/api/projects/${projectId}`],
  });

  const { data: contacts = [], isLoading } = useQuery<Contact[]>({
    queryKey: [`/api/projects/${projectId}/contacts`],
  });

  // Query for shared inboxes (team emails) for this show
  const { data: sharedInboxes = [] } = useQuery({
    queryKey: ['/api/shared-inboxes'],
  });

  // Query for user's personal email accounts
  const { data: emailAccounts = [] } = useQuery({
    queryKey: ['/api/email/accounts'],
    retry: false,
  });
  
  // Query for contact groups to get the group name
  const { data: contactGroups = [] } = useQuery<any[]>({
    queryKey: [`/api/projects/${projectId}/contact-groups`],
  });

  // Filter contacts by group
  const groupContacts = contacts.filter((contact: Contact) => {
    if (isUnassigned) {
      return !contact.groupId;
    }
    return contact.groupId === groupId;
  });

  // Get group display name
  const getGroupTitle = () => {
    if (isUnassigned) return 'Unassigned';
    const group = contactGroups.find((g: any) => g.id === groupId);
    return group?.name || 'Unknown Group';
  };

  const handleContactClick = (contact: Contact) => {
    setSelectedContact(contact);
    setShowContactModal(true);
  };

  const handleAddContact = () => {
    setEditingContact(null);
    setShowFormModal(true);
  };

  const handleEditContact = (contact: Contact) => {
    setEditingContact(contact);
    setShowContactModal(false);
    setShowFormModal(true);
  };

  const handleContactModalClose = () => {
    setShowContactModal(false);
    setSelectedContact(null);
  };

  const handleFormModalClose = () => {
    setShowFormModal(false);
    setEditingContact(null);
  };

  const handleFormSuccess = () => {
    setShowFormModal(false);
    setEditingContact(null);
    queryClient.invalidateQueries({ queryKey: [`/api/projects/${projectId}/contacts`] });
  };

  const handleEmailComposerClose = () => {
    setShowEmailComposer(false);
    setComposerRecipient('');
    setComposerFromAccount(null);
  };

  // Smart email handling function
  const handleEmailContact = (contactEmail: string) => {
    // Priority 1: Check for team/shared inbox email for this show
    const showSharedInbox = (sharedInboxes as any[]).find(
      (inbox: any) => inbox.projectId === parseInt(projectId!)
    );
    
    if (showSharedInbox?.emailAddress) {
      // Open local email composer with team email as from address
      setComposerFromAccount(showSharedInbox);
      setComposerRecipient(contactEmail);
      setShowEmailComposer(true);
      return;
    }

    // Priority 2: Check for personal email account
    const personalAccount = (emailAccounts as any[]).find(
      (account: any) => account.accountType === 'personal' || account.projectId === null
    );
    
    if (personalAccount?.emailAddress) {
      // Open local email composer with personal email as from address
      setComposerFromAccount(personalAccount);
      setComposerRecipient(contactEmail);
      setShowEmailComposer(true);
      return;
    }

    // Priority 3: Fallback to mailto if no email system setup
    window.location.href = `mailto:${contactEmail}`;
  };

  // Guard against invalid group URL parameters
  if (isInvalidGroupParam) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold text-foreground mb-2">Invalid Group</h1>
          <p className="text-muted-foreground mb-4">The group URL is invalid or malformed.</p>
          <Button onClick={() => setLocation(`/shows/${projectId}/contacts`)}>
            Go to Contacts
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="mb-6"></div>

        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold">{getGroupTitle()}</h1>
            <p className="text-gray-500 mt-2">
              {groupContacts.length} contact{groupContacts.length !== 1 ? 's' : ''}
            </p>
          </div>
          <Button onClick={handleAddContact} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Contact
          </Button>
        </div>

        {/* Contact List */}
        <div className="max-w-4xl mx-auto">
          {groupContacts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No contacts in this group yet</p>
              <Button onClick={handleAddContact} variant="outline">
                Add First Contact
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupContacts.map((contact: Contact) => (
                <div
                  key={contact.id}
                  className="group p-4 cursor-pointer transition-colors hover:bg-gray-50 rounded-lg"
                  onClick={() => handleContactClick(contact)}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">
                        {contact.firstName} {contact.lastName}
                      </h3>
                      {contact.role && (
                        <p className="text-sm text-gray-600 mt-1">{contact.role}</p>
                      )}
                    </div>
                    <div className="flex gap-2 ml-3">
                      <Calendar 
                        className="h-4 w-4 text-gray-600 hover:text-gray-800 cursor-pointer" 
                        onClick={(e) => {
                          e.stopPropagation();
                          setAvailabilityContact(contact);
                        }}
                      />
                      {contact.email ? (
                        <Mail 
                          className="h-4 w-4 text-gray-600 hover:text-gray-800 cursor-pointer" 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEmailContact(contact.email!);
                          }}
                        />
                      ) : (
                        <Mail className="h-4 w-4 text-gray-300" />
                      )}
                      {contact.phone ? (
                        <Phone 
                          className="h-4 w-4 text-gray-600 hover:text-gray-800 cursor-pointer" 
                          onClick={(e) => {
                            e.stopPropagation();
                            window.location.href = `tel:${contact.phone}`;
                          }}
                        />
                      ) : (
                        <Phone className="h-4 w-4 text-gray-300" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Contact Detail Modal */}
        <ContactDetailModal
          contact={selectedContact}
          isOpen={showContactModal}
          onClose={handleContactModalClose}
          onEdit={handleEditContact}
        />

        {/* Contact Form Modal */}
        <Dialog open={showFormModal} onOpenChange={setShowFormModal}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingContact ? "Edit Contact" : "Add New Contact"}
              </DialogTitle>
            </DialogHeader>
            <ContactForm
              projectId={projectId}
              category={groupParam}
              contact={editingContact}
              onClose={handleFormModalClose}
              onSuccess={handleFormSuccess}
            />
          </DialogContent>
        </Dialog>

        {/* Email Composer */}
        {showEmailComposer && composerFromAccount && (
          <GmailEmailComposer
            isOpen={showEmailComposer}
            onClose={handleEmailComposerClose}
            fromAccountId={composerFromAccount.id}
            fromEmail={composerFromAccount.emailAddress}
            initialRecipient={composerRecipient}
          />
        )}

        {/* Weekly Availability Editor */}
        {availabilityContact && (
          <WeeklyAvailabilityEditor 
            contact={availabilityContact}
            isOpen={true}
            onOpenChange={(open) => {
              if (!open) {
                setAvailabilityContact(null);
              }
            }}
          />
        )}
      </div>
    </div>
  );
}