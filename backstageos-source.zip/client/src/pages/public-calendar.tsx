import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calendar, Download, ExternalLink, Clock, MapPin, User, Mail, Eye, ChevronDown, ChevronUp } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { cn } from '@/lib/utils';

interface PublicCalendarData {
  project: {
    id: number;
    name: string;
    description: string;
  };
  contact: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    contactType: string;
  };
  events: Array<{
    id: number;
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    location: string;
    eventType: string;
    description: string;
    notes: string;
  }>;
}

export default function PublicCalendar() {
  const [calendarData, setCalendarData] = useState<PublicCalendarData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedEvents, setExpandedEvents] = useState<Record<number, boolean>>({});
  const { toast } = useToast();

  const toggleEventExpansion = (eventId: number) => {
    setExpandedEvents(prev => ({
      ...prev,
      [eventId]: !prev[eventId]
    }));
  };

  useEffect(() => {
    const fetchCalendarData = async () => {
      try {
        // Extract token from URL manually since this route is outside wouter routing
        const pathParts = window.location.pathname.split('/');
        const token = pathParts[pathParts.length - 1];
        
        if (!token || token === 'public-calendar') {
          throw new Error('No token provided');
        }

        const data = await apiRequest('GET', `/api/public-calendar/${token}`);
        setCalendarData(data);
      } catch (err: any) {
        setError(err.message || 'Failed to load calendar');
        toast({
          title: "Error",
          description: err.message || "Failed to load calendar",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchCalendarData();
  }, [toast]);

  // Group events by date
  const eventsByDate = calendarData?.events ? 
    calendarData.events.reduce((acc, event) => {
      const dateKey = event.date;
      if (!acc[dateKey]) {
        acc[dateKey] = [];
      }
      acc[dateKey].push(event);
      return acc;
    }, {} as Record<string, typeof calendarData.events>) : {};

  // Sort events within each date by time
  Object.values(eventsByDate).forEach(dayEvents => {
    dayEvents.sort((a, b) => {
      const timeA = a.startTime || '00:00:00';
      const timeB = b.startTime || '00:00:00';
      return timeA.localeCompare(timeB);
    });
  });

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric', 
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  const formatTime = (timeString: string) => {
    try {
      const [hours, minutes] = timeString.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return timeString;
    }
  };

  const generateGoogleCalendarLink = () => {
    if (!calendarData?.events || calendarData.events.length === 0) return '';

    // For multiple events, we'll create a link to add the first event
    const firstEvent = calendarData.events[0];
    if (firstEvent) {
      const startDateTime = new Date(`${firstEvent.date}T${firstEvent.startTime}`);
      const endDateTime = new Date(`${firstEvent.date}T${firstEvent.endTime}`);
      
      const formatDateForGoogle = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };

      const params = new URLSearchParams({
        action: 'TEMPLATE',
        text: firstEvent.title,
        dates: `${formatDateForGoogle(startDateTime)}/${formatDateForGoogle(endDateTime)}`,
        details: firstEvent.description || '',
        location: firstEvent.location || '',
        sprop: 'name:BackstageOS'
      });

      return `https://calendar.google.com/calendar/render?${params.toString()}`;
    }

    return '';
  };

  const downloadICSFile = () => {
    if (!calendarData?.events || calendarData.events.length === 0) return;

    const icsEvents = calendarData.events.map(event => {
      const startDateTime = new Date(`${event.date}T${event.startTime}`);
      const endDateTime = new Date(`${event.date}T${event.endTime}`);
      
      const formatDate = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };

      return [
        'BEGIN:VEVENT',
        `DTSTART:${formatDate(startDateTime)}`,
        `DTEND:${formatDate(endDateTime)}`,
        `SUMMARY:${event.title}`,
        `DESCRIPTION:${event.description || ''}`,
        `LOCATION:${event.location || ''}`,
        `UID:${event.id}@backstageos.com`,
        'END:VEVENT'
      ].join('\n');
    }).join('\n');

    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//BackstageOS//Personal Schedule//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      icsEvents,
      'END:VCALENDAR'
    ].join('\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${calendarData.project.name}_${calendarData.contact.firstName}_${calendarData.contact.lastName}_schedule.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Download Started",
      description: "Your personal schedule has been downloaded as an ICS file."
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-600">Loading your personal schedule...</p>
        </div>
      </div>
    );
  }

  if (error || !calendarData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-red-600">Access Error</CardTitle>
            <CardDescription>
              {error || 'This calendar link is invalid or has expired.'}
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-sm text-gray-600">
              Please contact your stage manager for a new link.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calendar className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">
              Personal Schedule
            </h1>
          </div>
          <p className="text-gray-600">
            {`${calendarData.contact.firstName} ${calendarData.contact.lastName}'s Schedule`}
          </p>
        </div>

        {/* Project & Contact Info */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl">Production Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Production</Label>
                <p className="text-lg font-semibold">{calendarData.project.name}</p>
                {calendarData.project.description && (
                  <p className="text-sm text-gray-600">{calendarData.project.description}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium text-gray-700">Team Member</Label>
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span className="font-medium">{calendarData.contact.firstName} {calendarData.contact.lastName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{calendarData.contact.email}</span>
                </div>
              </div>
            </div>

          </CardContent>
        </Card>

        {/* Schedule Actions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl">Add to Your Calendar</CardTitle>
            <CardDescription>
              Download your personal schedule or add events to Google Calendar
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={downloadICSFile}
                className="flex-1 flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Download ICS File
              </Button>
              <Button
                onClick={() => window.open(generateGoogleCalendarLink(), '_blank')}
                variant="outline"
                className="flex-1 flex items-center gap-2"
                disabled={!calendarData.events?.length}
              >
                <ExternalLink className="h-4 w-4" />
                Open in Google Calendar
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              The ICS file can be imported into most calendar applications including Google Calendar, Apple Calendar, and Outlook.
            </p>
          </CardContent>
        </Card>

        {/* Schedule Events */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">
              Schedule Events
              <Badge variant="secondary" className="ml-2">
                {calendarData.events?.length || 0} events
              </Badge>
            </CardTitle>
            <CardDescription>
              Your personal schedule for {calendarData.project.name}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {calendarData.events?.length ? (
              <div>
                {Object.entries(eventsByDate).map(([date, dayEvents], dateIndex) => (
                  <div key={date} className={dateIndex > 0 ? 'border-t' : ''}>
                    {/* Date Header */}
                    <div className="px-6 py-4 bg-gray-50 border-b">
                      <h3 className="text-lg font-semibold text-gray-900">{formatDate(date)}</h3>
                      <p className="text-sm text-gray-600">
                        {dayEvents.length} event{dayEvents.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                    
                    {/* Events for this date */}
                    <div className="divide-y">
                      {dayEvents.map((event) => (
                        <div key={event.id} className="p-6 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-start gap-3">
                              <div className="text-sm text-gray-600 min-w-[80px] pt-1">
                                <div className="font-medium">
                                  {formatTime(event.startTime)}
                                </div>
                                {event.endTime && (
                                  <div className="text-xs mt-1">
                                    {formatTime(event.endTime)}
                                  </div>
                                )}
                              </div>
                              <div className="flex-1">
                                <h4 className="font-semibold text-gray-900 mb-1">{event.title}</h4>
                                {event.location && (
                                  <div className="text-sm text-gray-600">
                                    {event.location}
                                  </div>
                                )}
                              </div>
                            </div>
                            <Badge variant="outline" className="flex-shrink-0">
                              {event.eventType}
                            </Badge>
                          </div>

                          {/* View Details Link */}
                          {event.description && (
                            <div className="ml-[92px] mb-3">
                              <button
                                onClick={() => toggleEventExpansion(event.id)}
                                className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center gap-1 transition-colors"
                              >
                                View details
                                {expandedEvents[event.id] ? (
                                  <ChevronUp className="h-3 w-3" />
                                ) : (
                                  <ChevronDown className="h-3 w-3" />
                                )}
                              </button>
                            </div>
                          )}

                          {/* Expandable Details */}
                          {event.description && expandedEvents[event.id] && (
                            <div className="ml-[92px] border-t pt-3">
                              <div className="space-y-2">
                                <div>
                                  <p className="text-sm font-medium text-gray-700 mb-1">Description</p>
                                  <p className="text-gray-700 text-sm">{event.description}</p>
                                </div>
                                {event.notes && (
                                  <div>
                                    <p className="text-sm font-medium text-gray-700 mb-1">Notes</p>
                                    <p className="text-gray-600 text-sm italic">{event.notes}</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500 px-6">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No events scheduled at this time.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Access Info */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <div className="flex items-center justify-center gap-2">
            <Eye className="h-3 w-3" />
            <span>
              Powered by BackstageOS
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}