import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Globe, Search, Bot, Image, Settings, Plus, Edit, Trash2, Eye, Copy, Upload, X } from "lucide-react";
import { Link } from "wouter";
import { insertSeoSettingsSchema, type SeoSettings, type InsertSeoSettings } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import AdminGuard from "@/components/admin-guard";

// Create a form-friendly schema - use partial() to allow any subset of fields
const formSchema = insertSeoSettingsSchema.partial();

type FormData = z.infer<typeof formSchema>;

const defaultStructuredData = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "BackstageOS",
  "applicationCategory": "BusinessApplication",
  "operatingSystem": "Web",
  "offers": {
    "@type": "Offer",
    "category": "SaaS"
  },
  "targetAudience": {
    "@type": "Audience",
    "audienceType": "Theater Professionals"
  }
};

function SeoManagerContent() {
  const [selectedSettings, setSelectedSettings] = useState<SeoSettings | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'preview'>('list');
  const [uploadingFavicon, setUploadingFavicon] = useState(false);
  const [uploadingShareImage, setUploadingShareImage] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: seoSettings = [], isLoading } = useQuery<SeoSettings[]>({
    queryKey: ['/api/seo-settings'],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      domain: "",
      siteTitle: "",
      siteDescription: "",
      keywords: "",
      faviconUrl: "",
      appleTouchIconUrl: "",
      shareImageUrl: "",
      shareImageAlt: "",
      twitterCard: "summary_large_image",
      twitterHandle: "",
      author: "",
      themeColor: "#2563eb",
      customMeta: {},
      openGraphType: "website",
      structuredData: defaultStructuredData,
      aiDescription: "",
      semanticKeywords: "",
      contentCategories: "",
      targetAudience: "Theater Professionals, Stage Managers",
      industryVertical: "Theater & Entertainment",
      functionalityTags: "Theater Management, Production Tools, Stage Management",
      aiMetadata: {},
      robotsDirectives: "index, follow",
      canonicalUrl: "",
      languageCode: "en-US",
      geoTargeting: "",
      bimiLogoUrl: "",
      bimiLogoAlt: "",
      bimiVmcUrl: "",
      bimiSelector: "default",
      bimiEnabled: false,
      isActive: true
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const result = await apiRequest('POST', '/api/seo-settings', data);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/seo-settings'] });
      toast({ title: "SEO settings created successfully" });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to create SEO settings",
        variant: "destructive" 
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<FormData> }) => {
      console.log('🌐 Making PUT request to /api/seo-settings/' + id);
      const result = await apiRequest('PUT', `/api/seo-settings/${id}`, data);
      console.log('✅ PUT response received:', result);
      return result;
    },
    onSuccess: (result) => {
      console.log('✅ Update successful:', result);
      queryClient.invalidateQueries({ queryKey: ['/api/seo-settings'] });
      toast({ title: "SEO settings updated successfully" });
      setIsDialogOpen(false);
      setSelectedSettings(null);
    },
    onError: (error: any) => {
      console.error('❌ Update error:', error);
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update SEO settings",
        variant: "destructive" 
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const result = await apiRequest('DELETE', `/api/seo-settings/${id}`);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/seo-settings'] });
      toast({ title: "SEO settings deleted successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to delete SEO settings",
        variant: "destructive" 
      });
    }
  });

  // BIMI management functions
  const handleBimiUpload = (settingsId: number) => {
    console.log('🔵 BIMI Upload starting for settings ID:', settingsId);
    
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.svg';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) {
        console.log('❌ No file selected');
        return;
      }

      console.log('📁 File selected:', file.name, file.type, file.size);

      const formData = new FormData();
      formData.append('logo', file);

      try {
        console.log('🚀 Sending upload request to:', `/api/seo-settings/${settingsId}/bimi/upload-logo`);
        
        const res = await fetch(`/api/seo-settings/${settingsId}/bimi/upload-logo`, {
          method: 'POST',
          body: formData,
        });
        
        console.log('📡 Response status:', res.status);
        console.log('📡 Response headers:', Object.fromEntries(res.headers.entries()));
        
        const result = await res.json();
        console.log('📊 Response data:', result);
        
        if (res.ok) {
          queryClient.invalidateQueries({ queryKey: ['/api/seo-settings'] });
          toast({ title: "BIMI logo uploaded successfully" });
        } else {
          throw new Error(result.message);
        }
      } catch (error: any) {
        console.error('❌ Upload error:', error);
        toast({ 
          title: "Error", 
          description: error.message || "Failed to upload BIMI logo",
          variant: "destructive" 
        });
      }
    };
    input.click();
  };

  const handleBimiCreateDNS = async (settingsId: number) => {
    try {
      const res = await apiRequest('POST', `/api/seo-settings/${settingsId}/bimi/create-dns-record`);
      const result = await res.json();
      
      toast({ 
        title: "BIMI DNS record created",
        description: `Created TXT record: ${result.record.name}`
      });
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to create BIMI DNS record",
        variant: "destructive" 
      });
    }
  };

  const handleBimiVerify = async (settingsId: number) => {
    try {
      const result = await apiRequest('POST', `/api/seo-settings/${settingsId}/bimi/verify`);
      
      const status = result.bimiCompliant ? "✅ BIMI Setup Complete" : "⚠️ BIMI Issues Found";
      const details = result.recommendations.join(', ');
      
      toast({ 
        title: status,
        description: details
      });
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to verify BIMI setup",
        variant: "destructive" 
      });
    }
  };

  const onSubmit = (data: FormData) => {
    console.log('🔍 Form submitted with data:', { selectedSettings: selectedSettings?.id, data });
    if (selectedSettings) {
      console.log('📤 Calling update mutation with ID:', selectedSettings.id);
      updateMutation.mutate({ id: selectedSettings.id, data });
    } else {
      console.log('📤 Calling create mutation');
      createMutation.mutate(data);
    }
  };

  // Image upload handlers
  const handleImageUpload = async (file: File, type: 'favicon' | 'shareImage') => {
    if (type === 'favicon') setUploadingFavicon(true);
    if (type === 'shareImage') setUploadingShareImage(true);

    try {
      const formData = new FormData();
      formData.append('image', file);
      formData.append('type', type);

      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      
      // Update form with uploaded image URL
      if (type === 'favicon') {
        form.setValue('faviconUrl', result.url);
        if (result.appleTouchIconUrl) {
          form.setValue('appleTouchIconUrl', result.appleTouchIconUrl);
        }
      } else if (type === 'shareImage') {
        form.setValue('shareImageUrl', result.url);
      }

      toast({ title: `${type === 'favicon' ? 'Favicon' : 'Share image'} uploaded successfully` });
    } catch (error) {
      toast({ 
        title: "Upload failed", 
        description: "Failed to upload image. Please try again.",
        variant: "destructive" 
      });
    } finally {
      if (type === 'favicon') setUploadingFavicon(false);
      if (type === 'shareImage') setUploadingShareImage(false);
    }
  };

  const handleImageRemove = (type: 'favicon' | 'shareImage') => {
    if (type === 'favicon') {
      form.setValue('faviconUrl', '');
      form.setValue('appleTouchIconUrl', '');
    } else if (type === 'shareImage') {
      form.setValue('shareImageUrl', '');
      form.setValue('shareImageAlt', '');
    }
    toast({ title: `${type === 'favicon' ? 'Favicon' : 'Share image'} removed` });
  };

  const handleEdit = (settings: SeoSettings) => {
    setSelectedSettings(settings);
    form.reset({
      domain: settings.domain || "",
      siteTitle: settings.siteTitle || "",
      siteDescription: settings.siteDescription || "",
      keywords: settings.keywords || "",
      faviconUrl: settings.faviconUrl || "",
      appleTouchIconUrl: settings.appleTouchIconUrl || "",
      shareImageUrl: settings.shareImageUrl || "",
      shareImageAlt: settings.shareImageAlt || "",
      twitterCard: settings.twitterCard || "summary_large_image",
      twitterHandle: settings.twitterHandle || "",
      author: settings.author || "",
      themeColor: settings.themeColor || "#2563eb",
      customMeta: settings.customMeta || {},
      openGraphType: settings.openGraphType || "website",
      structuredData: settings.structuredData || defaultStructuredData,
      aiDescription: settings.aiDescription || "",
      semanticKeywords: settings.semanticKeywords || "",
      contentCategories: settings.contentCategories || "",
      targetAudience: settings.targetAudience || "Theater Professionals, Stage Managers",
      industryVertical: settings.industryVertical || "Theater & Entertainment",
      functionalityTags: settings.functionalityTags || "Theater Management, Production Tools, Stage Management",
      aiMetadata: settings.aiMetadata || {},
      robotsDirectives: settings.robotsDirectives || "index, follow",
      canonicalUrl: settings.canonicalUrl || "",
      languageCode: settings.languageCode || "en-US",
      geoTargeting: settings.geoTargeting || "",
      bimiLogoUrl: settings.bimiLogoUrl || "",
      bimiLogoAlt: settings.bimiLogoAlt || "",
      bimiVmcUrl: settings.bimiVmcUrl || "",
      bimiSelector: settings.bimiSelector || "default",
      bimiEnabled: settings.bimiEnabled || false,
      isActive: settings.isActive
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete these SEO settings?")) {
      deleteMutation.mutate(id);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const testConnectivity = async () => {
    const tests = [];
    let allPassed = true;

    // Show single "running tests" notification
    toast({ title: "Running SEO & Connectivity Tests...", description: "Testing all components" });

    try {
      // Test 1: Internet connectivity
      const connectivityResponse = await fetch('https://httpbin.org/json');
      const connectivityData = await connectivityResponse.json();
      tests.push({
        name: "Internet Connectivity",
        status: "✅ PASS",
        details: `Server IP: ${connectivityData.origin}`
      });
    } catch (error) {
      tests.push({
        name: "Internet Connectivity", 
        status: "❌ FAIL",
        details: "Cannot connect to external services"
      });
      allPassed = false;
    }

    try {
      // Test 2: SEO Meta Tags Verification
      const currentUrl = window.location.origin;
      const metaResponse = await fetch(currentUrl);
      const htmlContent = await metaResponse.text();
      
      // Check for essential meta tags
      const hasTitle = htmlContent.includes('<title>') && htmlContent.includes('BackstageOS');
      const hasDescription = htmlContent.includes('name="description"') || htmlContent.includes('property="og:description"');
      const hasOgImage = htmlContent.includes('property="og:image"');
      const hasTwitterCard = htmlContent.includes('name="twitter:card"');
      const hasStructuredData = htmlContent.includes('application/ld+json');
      
      if (hasTitle && hasDescription && hasOgImage && hasTwitterCard && hasStructuredData) {
        tests.push({
          name: "SEO Meta Tags",
          status: "✅ PASS", 
          details: "All essential meta tags found in HTML"
        });
      } else {
        const missing = [];
        if (!hasTitle) missing.push("title");
        if (!hasDescription) missing.push("description");
        if (!hasOgImage) missing.push("og:image");
        if (!hasTwitterCard) missing.push("twitter:card");
        if (!hasStructuredData) missing.push("structured data");
        
        tests.push({
          name: "SEO Meta Tags",
          status: "⚠️ PARTIAL",
          details: `Missing: ${missing.join(", ")}`
        });
        allPassed = false;
      }
    } catch (error) {
      tests.push({
        name: "SEO Meta Tags",
        status: "❌ FAIL", 
        details: "Cannot fetch page HTML for analysis"
      });
      allPassed = false;
    }

    try {
      // Test 3: Share Image Accessibility
      const shareImageUrl = `${window.location.origin}/uploads/shareImage-1751581407362.png`;
      const imageResponse = await fetch(shareImageUrl, { method: 'HEAD' });
      
      if (imageResponse.ok) {
        const contentType = imageResponse.headers.get('content-type');
        const contentLength = imageResponse.headers.get('content-length');
        tests.push({
          name: "Share Image",
          status: "✅ PASS",
          details: `Image accessible (${contentType}, ${contentLength} bytes)`
        });
      } else {
        tests.push({
          name: "Share Image", 
          status: "❌ FAIL",
          details: `HTTP ${imageResponse.status}: Image not accessible`
        });
        allPassed = false;
      }
    } catch (error) {
      tests.push({
        name: "Share Image",
        status: "❌ FAIL",
        details: "Cannot verify image accessibility"
      });
      allPassed = false;
    }

    try {
      // Test 4: Social Media Indexability 
      const currentUrl = window.location.origin;
      const crawlerResponse = await fetch(currentUrl, {
        headers: {
          'User-Agent': 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)'
        }
      });
      
      if (crawlerResponse.ok) {
        const crawlerHtml = await crawlerResponse.text();
        const hasOgTags = crawlerHtml.includes('property="og:') && crawlerHtml.includes('property="og:image"');
        
        if (hasOgTags) {
          tests.push({
            name: "Social Media Indexability",
            status: "✅ PASS",
            details: "Page accessible to social media crawlers"
          });
        } else {
          tests.push({
            name: "Social Media Indexability", 
            status: "⚠️ PARTIAL",
            details: "Accessible but missing Open Graph tags"
          });
          allPassed = false;
        }
      } else {
        tests.push({
          name: "Social Media Indexability",
          status: "❌ FAIL", 
          details: `HTTP ${crawlerResponse.status}: Not accessible to crawlers`
        });
        allPassed = false;
      }
    } catch (error) {
      tests.push({
        name: "Social Media Indexability",
        status: "❌ FAIL",
        details: "Cannot test social media crawler access"
      });
      allPassed = false;
    }

    // Create single comprehensive results notification
    const passedCount = tests.filter(test => test.status.includes("PASS")).length;
    const totalTests = tests.length;
    const resultsDescription = tests.map(test => `${test.status} ${test.name}`).join(' • ');
    
    toast({
      title: allPassed ? `All ${totalTests} SEO Tests Passed!` : `SEO Tests Complete: ${passedCount}/${totalTests} Passed`,
      description: resultsDescription,
      variant: allPassed ? "default" : "destructive",
      duration: 8000 // Longer duration for comprehensive results
    });

    // Log detailed results to console for debugging
    console.log("SEO Test Results:");
    tests.forEach(test => {
      console.log(`${test.status} ${test.name}: ${test.details}`);
    });

    return allPassed;
  };

  const generateMetaTags = (settings: SeoSettings) => {
    return `<!-- Basic Meta Tags -->
<title>${settings.siteTitle}</title>
<meta name="description" content="${settings.siteDescription}" />
<meta name="keywords" content="${settings.keywords || ''}" />
<meta name="author" content="${settings.author || ''}" />
<meta name="robots" content="${settings.robotsDirectives}" />
<meta name="language" content="${settings.languageCode}" />
${settings.canonicalUrl ? `<link rel="canonical" href="${settings.canonicalUrl}" />` : ''}

<!-- Open Graph Tags -->
<meta property="og:title" content="${settings.siteTitle}" />
<meta property="og:description" content="${settings.siteDescription}" />
<meta property="og:type" content="${settings.openGraphType}" />
${settings.shareImageUrl ? `<meta property="og:image" content="${settings.shareImageUrl}" />` : ''}
${settings.shareImageAlt ? `<meta property="og:image:alt" content="${settings.shareImageAlt}" />` : ''}

<!-- Twitter Card Tags -->
<meta name="twitter:card" content="${settings.twitterCard}" />
${settings.twitterHandle ? `<meta name="twitter:site" content="${settings.twitterHandle}" />` : ''}
<meta name="twitter:title" content="${settings.siteTitle}" />
<meta name="twitter:description" content="${settings.siteDescription}" />
${settings.shareImageUrl ? `<meta name="twitter:image" content="${settings.shareImageUrl}" />` : ''}

<!-- Favicon and Icons -->
${settings.faviconUrl ? `<link rel="icon" href="${settings.faviconUrl}" />` : ''}
${settings.appleTouchIconUrl ? `<link rel="apple-touch-icon" href="${settings.appleTouchIconUrl}" />` : ''}

<!-- Theme and Mobile -->
<meta name="theme-color" content="${settings.themeColor}" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<!-- AI Optimization -->
<meta name="ai-description" content="${settings.aiDescription || settings.siteDescription}" />
<meta name="semantic-keywords" content="${settings.semanticKeywords || ''}" />
<meta name="content-categories" content="${settings.contentCategories || ''}" />
<meta name="target-audience" content="${settings.targetAudience || ''}" />
<meta name="industry-vertical" content="${settings.industryVertical || ''}" />

<!-- Structured Data -->
<script type="application/ld+json">
${JSON.stringify(settings.structuredData, null, 2)}
</script>`;
  };

  if (isLoading) {
    return <div className="p-8">Loading SEO settings...</div>;
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <div className="border-b bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex flex-col space-y-4 py-4 lg:py-6">
            <div className="mb-4"></div>
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 dark:text-white">SEO & AI Optimization</h1>
              <p className="text-sm lg:text-base text-gray-500 dark:text-gray-400">Manage search engine and AI optimization settings for all domains</p>
            </div>
            <div className="flex flex-col sm:flex-row w-full lg:w-auto space-y-3 sm:space-y-0 sm:space-x-3">
              <Button
                variant="outline"
                onClick={testConnectivity}
                className="w-full sm:w-auto"
                size="default"
              >
                <Globe className="mr-2 h-4 w-4" />
                Test SEO & Connectivity
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                onClick={() => setViewMode('list')}
                className="w-full sm:w-auto"
                size="default"
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
              <Button
                variant={viewMode === 'preview' ? 'default' : 'outline'}
                onClick={() => setViewMode('preview')}
                className="w-full sm:w-auto"
              >
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => {
                    setSelectedSettings(null);
                    form.reset();
                  }}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Domain
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {selectedSettings ? 'Edit SEO Settings' : 'Create SEO Settings'}
                    </DialogTitle>
                    <DialogDescription>
                      Configure search engine and AI optimization for your domain
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      {/* Basic Settings */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Globe className="mr-2 h-5 w-5" />
                          Basic Settings
                        </h3>
                        
                        <FormField
                          control={form.control}
                          name="domain"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Domain</FormLabel>
                              <FormControl>
                                <Input placeholder="example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="siteTitle"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Site Title</FormLabel>
                              <FormControl>
                                <Input placeholder="BackstageOS - Theater Management Platform" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="siteDescription"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Site Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Revolutionary theater management platform for professional stage managers..."
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        {/* Favicon Management */}
                        <div className="space-y-3">
                          <FormLabel>Favicon</FormLabel>
                          {form.watch('faviconUrl') ? (
                            <div className="flex items-center space-x-3">
                              <div className="flex-1">
                                <img 
                                  src={form.watch('faviconUrl').startsWith('http') ? form.watch('faviconUrl') : `${window.location.origin}${form.watch('faviconUrl')}`} 
                                  alt="Favicon preview" 
                                  className="h-8 w-8 rounded border"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).style.display = 'none';
                                  }}
                                />
                                <p className="text-xs text-gray-500 mt-1 truncate">
                                  {form.watch('faviconUrl')}
                                </p>
                              </div>
                              <div className="flex flex-col space-y-2">
                                <label htmlFor="faviconUpload">
                                  <Button type="button" variant="outline" size="sm" asChild disabled={uploadingFavicon}>
                                    <span className="cursor-pointer">
                                      {uploadingFavicon ? 'Uploading...' : 'Replace'}
                                    </span>
                                  </Button>
                                </label>
                                <Button 
                                  type="button" 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleImageRemove('favicon')}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                              <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-600 mb-2">Upload favicon</p>
                              <label htmlFor="faviconUpload">
                                <Button type="button" variant="outline" size="sm" asChild disabled={uploadingFavicon}>
                                  <span className="cursor-pointer">
                                    {uploadingFavicon ? 'Uploading...' : 'Choose File'}
                                  </span>
                                </Button>
                              </label>
                              <p className="text-xs text-gray-500 mt-2">Recommended: 32x32px or 16x16px, ICO or PNG</p>
                            </div>
                          )}
                          <input
                            id="faviconUpload"
                            type="file"
                            accept="image/*,.ico"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleImageUpload(file, 'favicon');
                            }}
                          />
                          <FormField
                            control={form.control}
                            name="faviconUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Favicon URL (or upload above)</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="https://example.com/favicon.ico" 
                                    name={field.name}
                                    ref={field.ref}
                                    onChange={field.onChange}
                                    onBlur={field.onBlur}
                                    value={field.value || ""}
                                    disabled={field.disabled}
                                  />
                                </FormControl>
                                <FormDescription>You can either upload an image above or enter a URL manually</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* SEO Optimization */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Search className="mr-2 h-5 w-5" />
                          SEO Optimization
                        </h3>
                        
                        <FormField
                          control={form.control}
                          name="keywords"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Keywords</FormLabel>
                              <FormControl>
                                <Input 
                                placeholder="theater management, stage management, production tools..." 
                                name={field.name}
                                ref={field.ref}
                                onChange={field.onChange}
                                onBlur={field.onBlur}
                                value={field.value || ""}
                                disabled={field.disabled}
                              />
                              </FormControl>
                              <FormDescription>Comma-separated keywords</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="robotsDirectives"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Robots Directives</FormLabel>
                              <FormControl>
                                <Input 
                                placeholder="index, follow" 
                                name={field.name}
                                ref={field.ref}
                                onChange={field.onChange}
                                onBlur={field.onBlur}
                                value={field.value || ""}
                                disabled={field.disabled}
                              />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="canonicalUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Canonical URL</FormLabel>
                              <FormControl>
                                <Input 
                                placeholder="https://backstageos.com" 
                                name={field.name}
                                ref={field.ref}
                                onChange={field.onChange}
                                onBlur={field.onBlur}
                                value={field.value || ""}
                                disabled={field.disabled}
                              />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* AI Optimization */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Bot className="mr-2 h-5 w-5" />
                          AI Optimization
                        </h3>
                        
                        <FormField
                          control={form.control}
                          name="aiDescription"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>AI-Optimized Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Detailed description optimized for AI systems and search engines..."
                                  name={field.name}
                                  ref={field.ref}
                                  onChange={field.onChange}
                                  onBlur={field.onBlur}
                                  value={field.value || ""}
                                  disabled={field.disabled}
                                />
                              </FormControl>
                              <FormDescription>Enhanced description for AI understanding</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="semanticKeywords"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Semantic Keywords</FormLabel>
                              <FormControl>
                                  <Input placeholder="show management, rehearsal coordination, production planning..." {...field} value={field.value || ""} />
                              </FormControl>
                              <FormDescription>LSI and semantic keywords for AI understanding</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="targetAudience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Target Audience</FormLabel>
                              <FormControl>
                                <Input placeholder="Theater Professionals, Stage Managers" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="industryVertical"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Industry Vertical</FormLabel>
                              <FormControl>
                                <Input placeholder="Theater & Entertainment" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="functionalityTags"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Functionality Tags</FormLabel>
                              <FormControl>
                                <Input placeholder="Theater Management, Production Tools, Stage Management" {...field} />
                              </FormControl>
                              <FormDescription>What the application does (comma-separated)</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* Social Media & Images */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Image className="mr-2 h-5 w-5" />
                          Social Media & Images
                        </h3>
                        
                        {/* Share Image Management */}
                        <div className="space-y-3">
                          <FormLabel>Share Image</FormLabel>
                          {form.watch('shareImageUrl') ? (
                            <div className="flex items-center space-x-3">
                              <div className="flex-1">
                                <img 
                                  src={form.watch('shareImageUrl').startsWith('http') ? form.watch('shareImageUrl') : `${window.location.origin}${form.watch('shareImageUrl')}`} 
                                  alt="Share preview" 
                                  className="h-20 w-auto rounded border"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).style.display = 'none';
                                  }}
                                />
                                <p className="text-xs text-gray-500 mt-1 truncate">
                                  {form.watch('shareImageUrl')}
                                </p>
                              </div>
                              <div className="flex flex-col space-y-2">
                                <label htmlFor="shareImageUpload">
                                  <Button type="button" variant="outline" size="sm" asChild disabled={uploadingShareImage}>
                                    <span className="cursor-pointer">
                                      {uploadingShareImage ? 'Uploading...' : 'Replace'}
                                    </span>
                                  </Button>
                                </label>
                                <Button 
                                  type="button" 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleImageRemove('shareImage')}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                              <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                              <p className="text-sm text-gray-600 mb-2">Upload share image (Open Graph)</p>
                              <label htmlFor="shareImageUpload">
                                <Button type="button" variant="outline" size="sm" asChild disabled={uploadingShareImage}>
                                  <span className="cursor-pointer">
                                    {uploadingShareImage ? 'Uploading...' : 'Choose File'}
                                  </span>
                                </Button>
                              </label>
                              <p className="text-xs text-gray-500 mt-2">Recommended: 1200x630px, PNG or JPG</p>
                            </div>
                          )}
                          <input
                            id="shareImageUpload"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleImageUpload(file, 'shareImage');
                            }}
                          />
                          <FormField
                            control={form.control}
                            name="shareImageUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Share Image URL (or upload above)</FormLabel>
                                <FormControl>
                                  <Input placeholder="https://example.com/og-image.jpg" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormDescription>You can either upload an image above or enter a URL manually</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="shareImageAlt"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Share Image Alt Text</FormLabel>
                              <FormControl>
                                <Input placeholder="BackstageOS theater management platform interface" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="twitterHandle"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Twitter Handle</FormLabel>
                              <FormControl>
                                <Input placeholder="@backstageos" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      {/* BIMI Configuration */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium flex items-center">
                          <Image className="mr-2 h-5 w-5" />
                          BIMI (Brand Indicators for Message Identification)
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Configure your brand logo to appear in email clients like Gmail and Apple Mail.
                        </p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="bimiEnabled"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base">Enable BIMI</FormLabel>
                                  <FormDescription>
                                    Activate BIMI for this domain
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={field.onChange}
                                    className="h-4 w-4"
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="bimiSelector"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>BIMI Selector</FormLabel>
                                <FormControl>
                                  <Input placeholder="default" {...field} value={field.value || "default"} />
                                </FormControl>
                                <FormDescription>DNS selector for BIMI record (usually "default")</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="bimiLogoUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>BIMI Logo URL</FormLabel>
                              <FormControl>
                                <Input placeholder="/uploads/bimi-logo.svg" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormDescription>Square SVG logo accessible via HTTPS</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="bimiLogoAlt"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Logo Alt Text</FormLabel>
                                <FormControl>
                                  <Input placeholder="BackstageOS Logo" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="bimiVmcUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>VMC URL (Optional)</FormLabel>
                                <FormControl>
                                  <Input placeholder="https://certificate-authority.com/vmc.pem" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormDescription>Verified Mark Certificate URL</FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <div className="flex justify-end space-x-4">
                        <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          disabled={createMutation.isPending || updateMutation.isPending}
                          onClick={() => {
                            const errors = form.formState.errors;
                            if (Object.keys(errors).length > 0) {
                              console.error('❌ Form validation errors:', errors);
                            }
                          }}
                        >
                          {createMutation.isPending || updateMutation.isPending 
                            ? "Saving..." 
                            : selectedSettings ? "Update" : "Create"
                          }
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
        {viewMode === 'list' ? (
          <div className="grid gap-6">
            {seoSettings.length === 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle>No SEO Settings</CardTitle>
                  <CardDescription>
                    Create your first SEO configuration to optimize your domains for search engines and AI systems.
                  </CardDescription>
                </CardHeader>
              </Card>
            ) : (
              seoSettings.map((settings: SeoSettings) => (
                <Card key={settings.id}>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-3">
                      <div className="space-y-2 flex-1">
                        <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
                          <Globe className="h-4 w-4 sm:h-5 sm:w-5" />
                          <span className="break-words">{settings.domain}</span>
                          {settings.isActive ? (
                            <Badge variant="default">Active</Badge>
                          ) : (
                            <Badge variant="secondary">Inactive</Badge>
                          )}
                        </CardTitle>
                        <CardDescription>{settings.siteTitle}</CardDescription>
                      </div>
                      <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => copyToClipboard(generateMetaTags(settings))}
                          className="w-full sm:w-auto justify-center sm:justify-start"
                        >
                          <Copy className="h-4 w-4 sm:mr-0" />
                          <span className="ml-2 sm:hidden">Copy</span>
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleEdit(settings)}
                          className="w-full sm:w-auto justify-center sm:justify-start"
                        >
                          <Edit className="h-4 w-4 sm:mr-0" />
                          <span className="ml-2 sm:hidden">Edit</span>
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDelete(settings.id)}
                          className="w-full sm:w-auto justify-center sm:justify-start"
                        >
                          <Trash2 className="h-4 w-4 sm:mr-0" />
                          <span className="ml-2 sm:hidden">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {settings.siteDescription}
                      </p>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium mb-2">SEO Features</h4>
                          <div className="space-y-1 text-sm">
                            {settings.keywords && (
                              <div className="flex items-center space-x-2">
                                <Search className="h-3 w-3" />
                                <span>Keywords: {settings.keywords.split(',').length}</span>
                              </div>
                            )}
                            {settings.shareImageUrl && (
                              <div className="flex items-center space-x-2">
                                <Image className="h-3 w-3" />
                                <span>Share Image</span>
                              </div>
                            )}
                            <div className="flex items-center space-x-2">
                              <Globe className="h-3 w-3" />
                              <span>Language: {settings.languageCode}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium mb-2">AI Optimization</h4>
                          <div className="space-y-1 text-sm">
                            {settings.aiDescription && (
                              <div className="flex items-center space-x-2">
                                <Bot className="h-3 w-3" />
                                <span>AI Description</span>
                              </div>
                            )}
                            {settings.semanticKeywords && (
                              <div className="flex items-center space-x-2">
                                <Bot className="h-3 w-3" />
                                <span>Semantic Keywords</span>
                              </div>
                            )}
                            <div className="flex items-center space-x-2">
                              <Bot className="h-3 w-3" />
                              <span>Industry: {settings.industryVertical}</span>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-medium mb-2">BIMI Configuration</h4>
                          <div className="space-y-1 text-sm">
                            <div className="flex items-center space-x-2">
                              <Image className="h-3 w-3" />
                              <span>Status: {settings.bimiEnabled ? "Enabled" : "Disabled"}</span>
                            </div>
                            {settings.bimiLogoUrl && (
                              <div className="flex items-center space-x-2">
                                <Image className="h-3 w-3" />
                                <span>Logo: {settings.bimiLogoUrl}</span>
                              </div>
                            )}
                            {settings.bimiEnabled && (
                              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mt-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleBimiUpload(settings.id)}
                                  className="w-full sm:w-auto"
                                >
                                  <Upload className="h-3 w-3 mr-1" />
                                  Upload Logo
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleBimiCreateDNS(settings.id)}
                                  className="w-full sm:w-auto"
                                >
                                  <Settings className="h-3 w-3 mr-1" />
                                  Create DNS
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleBimiVerify(settings.id)}
                                  className="w-full sm:w-auto"
                                >
                                  <Eye className="h-3 w-3 mr-1" />
                                  Verify
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {seoSettings.length === 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle>No SEO Settings to Preview</CardTitle>
                  <CardDescription>
                    Create SEO settings to see generated meta tags and structured data.
                  </CardDescription>
                </CardHeader>
              </Card>
            ) : (
              seoSettings.map((settings: SeoSettings) => (
                <Card key={settings.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{settings.domain} - Meta Tags Preview</span>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => copyToClipboard(generateMetaTags(settings))}
                      >
                        <Copy className="mr-2 h-4 w-4" />
                        Copy HTML
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg overflow-x-auto text-sm">
                      <code>{generateMetaTags(settings)}</code>
                    </pre>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function SeoManager() {
  return (
    <AdminGuard>
      <SeoManagerContent />
    </AdminGuard>
  );
}